djcharme
========

CHARMe project node


See the 
`docs directory <https://github.com/cedadev/djcharme/tree/develop/djcharme/docs>`_
for information on 
`installation <https://github.com/cedadev/djcharme/blob/develop/djcharme/docs/CHARMeNodeInstallation.pdf>`_,
the 
`interface <https://github.com/cedadev/djcharme/blob/develop/djcharme/docs/CHARMeNodeICD.pdf>`_
and examples.
